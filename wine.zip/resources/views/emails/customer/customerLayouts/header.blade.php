<div class="email-header">
    <img src="{{asset('images/logo.png')}}" style="width:200px;" alt="Logo">
</div>