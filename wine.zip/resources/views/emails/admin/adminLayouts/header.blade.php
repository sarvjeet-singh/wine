<div class="header">
    <h1>New Email Notification</h1>
</div>
