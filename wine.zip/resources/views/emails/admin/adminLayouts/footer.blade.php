<div style="text-align: center;">
    <img src="images/logo.png" style="width:200px;" alt="Logo">
    <div class="social-icons">
        <ul>
            <li>
                <a href="#">
                    <img src="images/image 13.png" style="width:27px; height: 27px;" alt="Instagram">
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/image 12.png" style="width:26px; height: 26px;" alt="YouTube">
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/image 11.png" style="width:26px; height: 26px;" alt="TikTok">
                </a>
            </li>
            <li>
                <a href="#"><img src="images/image 10.png" style="width:26px; height: 26px;" alt="Facebook">
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/twitter-x.png" style="width:25px; height: 25px;" alt="Twitter">
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="images/image 14.png" style="width:26px; height: 26px;" alt="LinkedIn">
                </a>
            </li>
        </ul>
    </div>
</div>
<div class="footer">
    &copy; 2024 Wine Country Weekends | All Rights Reserved
</div>