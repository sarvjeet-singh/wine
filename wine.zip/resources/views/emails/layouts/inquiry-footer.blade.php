<div style="text-align: center;">

    <img src="images/logo.png" style="width:180px;" alt="Logo">

    <div class="social-icons">

        <ul>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/instagram.png" style="width:27px; height: 27px;" alt="Instagram">

                </a>

            </li>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/youtube.png" style="width:26px; height: 26px;" alt="YouTube">

                </a>

            </li>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/tiktok.png" style="width:26px; height: 26px;" alt="TikTok">

                </a>

            </li>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/facebook.png" style="width:26px; height: 26px;" alt="Facebook">

                </a>

            </li>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/twitter-x.png" style="width:25px; height: 25px;" alt="Twitter">

                </a>

            </li>

            <li>

                <a href="#">

                    <img src="https://testing.winecountryweekends.ca/images/email-templates/linkedin.png" style="width:26px; height: 26px;" alt="LinkedIn">

                </a>

            </li>

        </ul>

    </div>

</div>

<div class="footer">

    &copy; {{ date('Y') }} Wine Country Weekends | All Rights Reserved

</div>

<!-- /Email Footer -->

</div>

