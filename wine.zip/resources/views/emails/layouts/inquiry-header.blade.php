<div class="email-container">
    <!-- Email Header -->
    <div class="header">
        <h1>Travel Inquiries</h1>
    </div>
    <!-- /Email Header -->

    <!-- Email Body -->
    <div class="content">
        <div class="section">
            <p style="margin: 0;font-size: 18px;font-style: italic;">Dear <span style="font-weight: 600;">Admin</span>,
            </p>
            <p style="margin-top: 10px;font-size: 15px;font-style: italic;">A new inquiry has been submitted. Below are
                the details:</p>
        </div>
