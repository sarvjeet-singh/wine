@extends('FrontEnd.layouts.mainapp')

@section('content')

<div class="container my-5">
	<div class="row">
		<div class="col-12">
			<h2>Privacy Policy</h2>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero quisq uam consectetur quidem illo porro excepturi minima perferendis cumque, odit fuga reprehenderit corporis rerum cum, blanditiis dolorem quae expedita minus vel.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero quisquam consectetur quidem illo porro excepturi minima perferendis cumque, odit fuga reprehenderit corporis rerum cum, blanditiis dolorem qua  ipsum dolor sit amet, consectetur adipisicing elit. Vero quisquam consectetur quidem illo porro excepturi minima perfer endis cumque, odit fuga reprehenderit corporis rerum cum, blanditiis dolorem que exp edita minus vel.  ipsum dolor sit amet, consectetur adipisicing elit. Vero quisquam consectetur quidem illo porro excepturi minima perferendis cumque, odit fuga reprehenderit corporis rerum cum, blanditiis dolorem qu</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero quisquam consectetur quidem illo porro excepturi minima perferendis cumque, odit fuga reprehenderit corporis rerum cum, blanditiis dolorem quae expedita minus vel.</p>
		</div>
	</div>
</div>


@endsection